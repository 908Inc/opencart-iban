<div class="buttons">
  <div class="pull-right">
    <input type="button" value="<?php echo $button_pay; ?>" id="button-confirm" class="btn btn-primary" data-loading-text="<?php echo $text_loading; ?>" />
  </div>
</div>

<script type="text/javascript">
$('#button-confirm').on('click', function() {
  $.ajax({
    url: 'index.php?route=extension/payment/opencart_iban/confirm',
    dataType: 'json',
    beforeSend: function() {
      $('#button-confirm').button('loading');
    },
    complete: function() {
      $('#button-confirm').button('reset');
    },
    success: function(json) {
      if (json['redirect']) {
        location = json['redirect'];
        return;
      }

      if (json['error']) {
        alert(json['error']);
      }
    },
    error: function(xhr, ajaxOptions, thrownError) {
      alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
    }
  });
});
</script>
